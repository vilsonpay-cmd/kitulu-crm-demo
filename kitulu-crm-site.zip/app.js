const STATUS_OPTIONS = [
  "Novo contacto",
  "Em qualificação",
  "Diagnóstico/Briefing",
  "Proposta em preparação",
  "Proposta enviada",
  "Em negociação",
  "Venda confirmada",
  "Em execução",
  "Concluído",
  "Pós-venda",
  "Cliente recorrente",
  "Perdido",
  "Sem resposta"
];

const SERVICE_OPTIONS = ["Floral Design", "Floral Direction", "Floral Subscription", "Formação", "Outro"];
const SOURCE_OPTIONS = ["Instagram", "WhatsApp", "Website", "Google", "Email", "Telefone", "Presencial", "Referência", "Parceria", "Prospecção"];
const STORAGE_KEY = "kitulu-crm-proposta-v1";
const today = new Date();
const dateISO = (offset = 0) => {
  const date = new Date(today);
  date.setDate(date.getDate() + offset);
  return date.toISOString().slice(0, 10);
};

const demoRecords = [
  { id: "KT-2401", client: "Leonor Matos", company: "Casa do Pátio", phone: "", email: "", source: "Referência", service: "Floral Design", need: "Composição floral para um jantar intimista de primavera.", serviceDate: dateISO(18), location: "Lisboa", estimate: 1850, proposal: 1850, status: "Proposta enviada", owner: "Paula Lunardelli", lastContact: dateISO(-1), nextAction: "Confirmar receção da proposta", nextActionDate: dateISO(0), result: "Em aberto", lossReason: "", closeDate: "", afterSales: "Não aplicável", rating: "", nextContact: dateISO(0), notes: "Registo fictício de demonstração." },
  { id: "KT-2402", client: "Marta Vale", company: "Atelier Vale", phone: "", email: "", source: "Instagram", service: "Floral Direction", need: "Direção floral para lançamento de coleção.", serviceDate: dateISO(33), location: "Porto", estimate: 3400, proposal: 3200, status: "Em negociação", owner: "Paula Lunardelli", lastContact: dateISO(-2), nextAction: "Agendar chamada de alinhamento", nextActionDate: dateISO(1), result: "Em aberto", lossReason: "", closeDate: "", afterSales: "Não aplicável", rating: "", nextContact: dateISO(1), notes: "Registo fictício de demonstração." },
  { id: "KT-2403", client: "Rita Neves", company: "Ritual Café", phone: "", email: "", source: "Website", service: "Floral Subscription", need: "Flores sazonais para o espaço, com entregas quinzenais.", serviceDate: dateISO(14), location: "Lisboa", estimate: 960, proposal: 960, status: "Venda confirmada", owner: "Joana Costa", lastContact: dateISO(-3), nextAction: "Preparar primeira entrega", nextActionDate: dateISO(3), result: "Ganho", lossReason: "", closeDate: dateISO(-2), afterSales: "Não aplicável", rating: "", nextContact: dateISO(3), notes: "Registo fictício de demonstração." },
  { id: "KT-2404", client: "Inês Correia", company: "Norte Criativo", phone: "", email: "", source: "Parceria", service: "Floral Design", need: "Ambientação floral para celebração de equipa.", serviceDate: dateISO(45), location: "Braga", estimate: 2400, proposal: 0, status: "Em qualificação", owner: "Joana Costa", lastContact: dateISO(-1), nextAction: "Enviar referências de estilo", nextActionDate: dateISO(2), result: "Em aberto", lossReason: "", closeDate: "", afterSales: "Não aplicável", rating: "", nextContact: dateISO(2), notes: "Registo fictício de demonstração." },
  { id: "KT-2405", client: "Sofia Almeida", company: "Casa Amora", phone: "", email: "", source: "WhatsApp", service: "Floral Direction", need: "Conceito floral para cerimónia e receção.", serviceDate: dateISO(60), location: "Sintra", estimate: 4600, proposal: 4600, status: "Proposta em preparação", owner: "Paula Lunardelli", lastContact: dateISO(-2), nextAction: "Finalizar proposta e moodboard", nextActionDate: dateISO(4), result: "Em aberto", lossReason: "", closeDate: "", afterSales: "Não aplicável", rating: "", nextContact: dateISO(4), notes: "Registo fictício de demonstração." },
  { id: "KT-2406", client: "Teresa Rocha", company: "—", phone: "", email: "", source: "Google", service: "Formação", need: "Workshop de composição floral para equipa.", serviceDate: dateISO(12), location: "Cascais", estimate: 780, proposal: 780, status: "Concluído", owner: "Marta Silva", lastContact: dateISO(-4), nextAction: "Pedir feedback pós-formação", nextActionDate: dateISO(5), result: "Ganho", lossReason: "", closeDate: dateISO(-1), afterSales: "Sim", rating: 5, nextContact: dateISO(5), notes: "Registo fictício de demonstração." },
  { id: "KT-2407", client: "Carolina Reis", company: "Casa do Pátio", phone: "", email: "", source: "Presencial", service: "Floral Subscription", need: "Renovar assinatura floral para o espaço.", serviceDate: dateISO(25), location: "Lisboa", estimate: 1260, proposal: 1260, status: "Cliente recorrente", owner: "Paula Lunardelli", lastContact: dateISO(-5), nextAction: "Confirmar preferências sazonais", nextActionDate: dateISO(7), result: "Ganho", lossReason: "", closeDate: dateISO(-5), afterSales: "Sim", rating: 5, nextContact: dateISO(7), notes: "Registo fictício de demonstração." },
  { id: "KT-2408", client: "Beatriz Lopes", company: "Studio Brisa", phone: "", email: "", source: "Email", service: "Floral Design", need: "Peças florais para apresentação de produto.", serviceDate: dateISO(22), location: "Porto", estimate: 2150, proposal: 0, status: "Novo contacto", owner: "Marta Silva", lastContact: dateISO(0), nextAction: "Marcar conversa de descoberta", nextActionDate: dateISO(6), result: "Em aberto", lossReason: "", closeDate: "", afterSales: "Não aplicável", rating: "", nextContact: dateISO(6), notes: "Registo fictício de demonstração." }
];

let opportunities = readRecords();
let activeView = "dashboard";
let query = "";
let toastTimer;

function readRecords() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (!saved) return demoRecords;
  try {
    const records = JSON.parse(saved);
    if (!Array.isArray(records)) throw new Error("O formato dos registos guardados é inválido.");
    return records;
  } catch (error) {
    console.error("Não foi possível carregar os registos locais do Kitulu CRM.", error);
    return demoRecords;
  }
}

function persistRecords() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(opportunities));
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}

function initials(name) {
  return name.trim().split(/\s+/).slice(0, 2).map(part => part[0] || "").join("").toUpperCase();
}

function slug(value) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function euro(value) {
  return new Intl.NumberFormat("pt-PT", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(Number(value) || 0);
}

function formatDate(value, options = { day: "2-digit", month: "short" }) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("pt-PT", options).format(new Date(`${value}T12:00:00`));
}

function relativeDate(value) {
  if (!value) return "Sem data";
  const delta = Math.round((new Date(`${value}T12:00:00`) - new Date(`${dateISO()}T12:00:00`)) / 86400000);
  if (delta === 0) return "Hoje";
  if (delta === 1) return "Amanhã";
  if (delta === -1) return "Ontem";
  return formatDate(value, { weekday: "short", day: "2-digit", month: "short" });
}

function contactable(opportunity) {
  return `${opportunity.client} ${opportunity.company} ${opportunity.service} ${opportunity.source} ${opportunity.status} ${opportunity.owner} ${opportunity.nextAction}`.toLocaleLowerCase("pt-PT");
}

function filteredOpportunities() {
  const status = document.querySelector("#status-filter")?.value || "";
  const service = document.querySelector("#service-filter")?.value || "";
  const search = query.trim().toLocaleLowerCase("pt-PT");
  return opportunities.filter(item =>
    (!status || item.status === status) &&
    (!service || item.service === service) &&
    (!search || contactable(item).includes(search))
  );
}

function activeOpportunities() {
  return opportunities.filter(item => !["Perdido", "Sem resposta"].includes(item.status));
}

function renderMetrics() {
  const active = activeOpportunities();
  const proposalValue = active.reduce((sum, item) => sum + Number(item.proposal || item.estimate || 0), 0);
  const closed = opportunities.filter(item => ["Ganho", "Perdido"].includes(item.result));
  const won = closed.filter(item => item.result === "Ganho").length;
  const conversion = closed.length ? Math.round((won / closed.length) * 100) : 0;
  const due = opportunities.filter(item => !["Perdido", "Sem resposta", "Cliente recorrente"].includes(item.status) && item.nextActionDate >= dateISO()).length;
  const metrics = [
    { label: "Oportunidades ativas", value: active.length, note: "em acompanhamento", icon: "↗", tone: "" },
    { label: "Valor em pipeline", value: euro(proposalValue), note: "estimativa de propostas", icon: "€", tone: "amber" },
    { label: "Conversão", value: `${conversion}%`, note: "nas oportunidades concluídas", icon: "◎", tone: "lilac" },
    { label: "Próximos follow-ups", value: due, note: "ações com data definida", icon: "⌁", tone: "blue" }
  ];
  document.querySelector("#metric-grid").innerHTML = metrics.map(metric => `
    <article class="metric-card">
      <div class="metric-top"><span>${metric.label}</span><span class="metric-icon ${metric.tone}">${metric.icon}</span></div>
      <div class="metric-value">${metric.value}</div>
      <div class="metric-foot"><span>${metric.note}</span></div>
    </article>`).join("");
}

function renderPipeline() {
  const groups = [
    { label: "Contacto & descoberta", statuses: ["Novo contacto", "Em qualificação", "Diagnóstico/Briefing"] },
    { label: "Preparação & proposta", statuses: ["Proposta em preparação", "Proposta enviada"] },
    { label: "Negociação", statuses: ["Em negociação"] },
    { label: "Entrega & fidelização", statuses: ["Venda confirmada", "Em execução", "Concluído", "Pós-venda", "Cliente recorrente"] }
  ];
  const active = activeOpportunities();
  document.querySelector("#pipeline-total").textContent = active.length;
  document.querySelector("#pipeline").innerHTML = groups.map(group => {
    const count = active.filter(item => group.statuses.includes(item.status)).length;
    const width = active.length ? Math.max(count ? 8 : 0, Math.round(count / active.length * 100)) : 0;
    return `<div class="pipeline-stage"><div class="stage-name">${group.label}</div><div class="stage-count">${count} <span>${count === 1 ? "oportunidade" : "oportunidades"}</span></div><div class="stage-track"><span style="width:${width}%"></span></div></div>`;
  }).join("");
}

function renderFollowups() {
  const items = opportunities
    .filter(item => item.nextActionDate && item.nextActionDate >= dateISO() && !["Perdido", "Sem resposta"].includes(item.status))
    .sort((a, b) => a.nextActionDate.localeCompare(b.nextActionDate))
    .slice(0, 3);
  document.querySelector("#followup-count").textContent = opportunities.filter(item => item.nextActionDate === dateISO()).length;
  document.querySelector("#followup-list").innerHTML = items.length ? items.map((item, index) => {
    const parts = item.nextActionDate.split("-");
    return `<button class="followup-item" data-id="${escapeHTML(item.id)}">
      <span class="followup-date"><strong>${parts[2]}</strong>${new Intl.DateTimeFormat("pt-PT", { month: "short" }).format(new Date(`${item.nextActionDate}T12:00:00`))}</span>
      <span class="followup-copy"><strong>${escapeHTML(item.nextAction)}</strong><span>${escapeHTML(item.client)} · ${relativeDate(item.nextActionDate)}</span></span>
      <span class="followup-owner">${escapeHTML(initials(item.owner))}</span>
    </button>`;
  }).join("") : `<div class="empty-row">Sem ações agendadas. Defina uma próxima ação ao registar uma oportunidade.</div>`;
}

function clientMarkup(item, index) {
  const company = item.company && item.company !== "—" ? item.company : "Cliente particular";
  return `<span class="client-cell"><span class="mini-avatar tone-${index % 5}">${escapeHTML(initials(item.client))}</span><span class="client-name"><strong>${escapeHTML(item.client)}</strong><span>${escapeHTML(company)}</span></span></span>`;
}

function ownerMarkup(owner) {
  return `<span class="owner-cell"><span class="owner-mini">${escapeHTML(initials(owner))}</span>${escapeHTML(owner || "Por atribuir")}</span>`;
}

function statusMarkup(status) {
  return `<span class="status-pill status-${slug(status)}">${escapeHTML(status || "Novo contacto")}</span>`;
}

function nextMarkup(item) {
  return `<span class="next-cell"><strong>${escapeHTML(item.nextAction || "Definir próxima ação")}</strong><span>${escapeHTML(relativeDate(item.nextActionDate))}</span></span>`;
}

function renderDashboardTable() {
  const items = opportunities.filter(item => !query.trim() || contactable(item).includes(query.trim().toLocaleLowerCase("pt-PT"))).slice(0, 5);
  document.querySelector("#dashboard-rows").innerHTML = items.length ? items.map((item, index) => `
    <tr data-id="${escapeHTML(item.id)}">
      <td>${clientMarkup(item, index)}</td>
      <td class="service-cell">${escapeHTML(item.service)}</td>
      <td>${statusMarkup(item.status)}</td>
      <td>${ownerMarkup(item.owner)}</td>
      <td class="money-cell">${euro(item.proposal || item.estimate)}</td>
      <td>${nextMarkup(item)}</td><td class="row-arrow">›</td>
    </tr>`).join("") : `<tr><td class="empty-row" colspan="7">Não encontrámos oportunidades para esta pesquisa.</td></tr>`;
}

function renderOpportunityTable() {
  const items = filteredOpportunities();
  document.querySelector("#opportunity-rows").innerHTML = items.length ? items.map((item, index) => `
    <tr data-id="${escapeHTML(item.id)}">
      <td>${clientMarkup(item, index)}</td>
      <td class="service-cell">${escapeHTML(item.service)}</td>
      <td>${statusMarkup(item.status)}</td>
      <td>${escapeHTML(item.source || "—")}</td>
      <td>${ownerMarkup(item.owner)}</td>
      <td class="money-cell">${euro(item.proposal || item.estimate)}</td>
      <td>${nextMarkup(item)}</td><td class="row-arrow">›</td>
    </tr>`).join("") : `<tr><td class="empty-row" colspan="8">Sem resultados. Ajuste os filtros ou crie uma nova oportunidade.</td></tr>`;
  document.querySelector("#all-count").textContent = opportunities.length;
  document.querySelector("#table-summary").textContent = `${items.length} ${items.length === 1 ? "oportunidade" : "oportunidades"}${query || document.querySelector("#status-filter").value || document.querySelector("#service-filter").value ? " encontradas" : ""}`;
}

function renderClients() {
  const unique = new Map();
  opportunities.forEach(item => {
    const key = item.client.trim().toLocaleLowerCase("pt-PT");
    if (!key) return;
    if (!unique.has(key)) unique.set(key, { ...item, opportunityCount: 0, latest: item.lastContact || "" });
    const client = unique.get(key);
    client.opportunityCount += 1;
    if (item.lastContact && item.lastContact > client.latest) client.latest = item.lastContact;
    if (item.rating) client.rating = item.rating;
  });
  const search = query.trim().toLocaleLowerCase("pt-PT");
  const clients = [...unique.values()].filter(item => !search || `${item.client} ${item.company} ${item.email} ${item.phone}`.toLocaleLowerCase("pt-PT").includes(search));
  document.querySelector("#client-rows").innerHTML = clients.length ? clients.map((item, index) => `
    <tr data-id="${escapeHTML(item.id)}">
      <td>${clientMarkup(item, index)}</td>
      <td>${escapeHTML(item.company && item.company !== "—" ? item.company : "—")}</td>
      <td>${item.email ? `<a class="contact-link" href="mailto:${escapeHTML(item.email)}">${escapeHTML(item.email)}</a>` : item.phone ? `<a class="contact-link" href="tel:${escapeHTML(item.phone)}">${escapeHTML(item.phone)}</a>` : "—"}</td>
      <td>${item.opportunityCount} ${item.opportunityCount === 1 ? "pedido" : "pedidos"}</td>
      <td>${item.latest ? formatDate(item.latest) : "—"}</td>
      <td>${item.rating ? `<span class="stars">${"★".repeat(Number(item.rating))}${"☆".repeat(5 - Number(item.rating))}</span>` : "—"}</td>
      <td class="row-arrow">›</td>
    </tr>`).join("") : `<tr><td class="empty-row" colspan="7">Ainda não há clientes para apresentar.</td></tr>`;
  document.querySelector("#client-count").textContent = unique.size;
}

function render() {
  renderMetrics();
  renderPipeline();
  renderFollowups();
  renderDashboardTable();
  renderOpportunityTable();
  renderClients();
  document.querySelector("#nav-opportunity-count").textContent = opportunities.length;
}

function showView(view) {
  activeView = view;
  document.querySelectorAll(".view").forEach(section => section.classList.toggle("active", section.id === `view-${view}`));
  document.querySelectorAll(".nav-link").forEach(button => button.classList.toggle("active", button.dataset.view === view));
  const labels = { dashboard: "VISÃO GERAL", opportunities: "OPORTUNIDADES", clients: "CLIENTES" };
  document.querySelector("#breadcrumb-current").textContent = labels[view];
  if (view === "opportunities") document.querySelector("#opportunities-title").focus?.({ preventScroll: true });
}

function populateSelect(select, values, placeholder) {
  select.innerHTML = `${placeholder ? `<option value="">${placeholder}</option>` : ""}${values.map(value => `<option value="${escapeHTML(value)}">${escapeHTML(value)}</option>`).join("")}`;
}

function fillNewFormOptions() {
  const form = document.querySelector("#new-opportunity-form");
  populateSelect(form.elements.service, SERVICE_OPTIONS);
  populateSelect(form.elements.source, SOURCE_OPTIONS);
  populateSelect(form.elements.status, STATUS_OPTIONS);
  form.elements.nextActionDate.value = dateISO(1);
}

function openNewModal() {
  const form = document.querySelector("#new-opportunity-form");
  form.reset();
  fillNewFormOptions();
  document.querySelector("#new-modal").showModal();
}

function showDetail(id) {
  const item = opportunities.find(record => record.id === id);
  if (!item) return;
  const details = [
    ["ID da oportunidade", item.id], ["Estado", item.status], ["Origem", item.source], ["Responsável", item.owner],
    ["Data de entrada", formatDate(item.dateIn)], ["Data do serviço", formatDate(item.serviceDate)],
    ["Valor estimado", euro(item.estimate)], ["Valor da proposta", euro(item.proposal)],
    ["Empresa", item.company || "—"], ["Contacto", item.email || item.phone || "—"],
    ["Local", item.location || "—"], ["Último contacto", formatDate(item.lastContact)],
    ["Resultado", item.result], ["Motivo de perda", item.lossReason || "—"],
    ["Pós-venda", item.afterSales], ["Satisfação", item.rating ? `${item.rating}/5` : "—"],
    ["Necessidade / pedido", item.need || "—"], ["Notas", item.notes || "—"]
  ];
  document.querySelector("#detail-content").innerHTML = `
    <div class="detail-content">
      <div class="detail-top">
        <span class="mini-avatar">${escapeHTML(initials(item.client))}</span>
        <div class="detail-top-copy"><p class="eyebrow">${escapeHTML(item.id)} · ${escapeHTML(item.service)}</p><h2>${escapeHTML(item.client)}</h2><p>${escapeHTML(item.company || "Cliente particular")} · ${statusMarkup(item.status)}</p></div>
        <button class="modal-close detail-close" data-action="close-detail" aria-label="Fechar">×</button>
      </div>
      <div class="detail-grid">
        ${details.map(([label, value]) => `<div class="detail-item ${label === "Necessidade / pedido" || label === "Notas" ? "wide" : ""}"><span>${escapeHTML(label)}</span><strong>${escapeHTML(value || "—")}</strong></div>`).join("")}
        <div class="detail-item wide detail-next"><span>Próxima ação · ${escapeHTML(relativeDate(item.nextActionDate))}</span><strong>${escapeHTML(item.nextAction || "Sem ação definida")}</strong></div>
      </div>
    </div>`;
  document.querySelector("#detail-modal").showModal();
}

function showToast(message) {
  const toast = document.querySelector("#toast");
  toast.textContent = message;
  toast.classList.add("visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("visible"), 2800);
}

function exportCSV() {
  const headers = ["ID", "Data de entrada", "Cliente", "Empresa", "Telefone", "Email", "Origem", "Linha de serviço", "Necessidade / pedido", "Data do serviço", "Local", "Valor estimado (€)", "Valor da proposta (€)", "Estado", "Responsável", "Último contacto", "Próxima ação", "Data da próxima ação", "Resultado", "Motivo de perda", "Data de conclusão", "Pós-venda realizado?", "Satisfação (1-5)", "Próximo contacto", "Notas"];
  const keys = ["id", "dateIn", "client", "company", "phone", "email", "source", "service", "need", "serviceDate", "location", "estimate", "proposal", "status", "owner", "lastContact", "nextAction", "nextActionDate", "result", "lossReason", "closeDate", "afterSales", "rating", "nextContact", "notes"];
  const csvCell = value => `"${String(value ?? "").replace(/"/g, '""')}"`;
  const contents = [headers, ...filteredOpportunities().map(item => keys.map(key => item[key] ?? ""))].map(row => row.map(csvCell).join(";")).join("\r\n");
  const blob = new Blob(["\ufeff", contents], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `kitulu-crm-${dateISO()}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
  showToast("Exportação CSV iniciada.");
}

document.addEventListener("click", event => {
  const viewButton = event.target.closest("[data-view]");
  if (viewButton) showView(viewButton.dataset.view);

  const goButton = event.target.closest("[data-go]");
  if (goButton) showView(goButton.dataset.go);

  const actionButton = event.target.closest("[data-action]");
  if (actionButton) {
    const action = actionButton.dataset.action;
    if (action === "new") openNewModal();
    if (action === "export") exportCSV();
    if (action === "close-new") document.querySelector("#new-modal").close();
    if (action === "close-detail") document.querySelector("#detail-modal").close();
  }

  const row = event.target.closest("[data-id]");
  if (row) showDetail(row.dataset.id);
});

document.querySelector("#global-search").addEventListener("input", event => {
  query = event.target.value;
  renderDashboardTable();
  renderOpportunityTable();
  renderClients();
});
document.querySelector("#status-filter").addEventListener("change", renderOpportunityTable);
document.querySelector("#service-filter").addEventListener("change", renderOpportunityTable);
document.querySelector(".banner-close").addEventListener("click", () => document.querySelector(".demo-banner").remove());

document.querySelector("#new-opportunity-form").addEventListener("submit", event => {
  event.preventDefault();
  const form = event.currentTarget;
  const values = Object.fromEntries(new FormData(form).entries());
  const record = {
    id: `KT-${String(Date.now()).slice(-6)}`,
    dateIn: dateISO(),
    client: values.client.trim(),
    company: values.company.trim() || "—",
    phone: "",
    email: "",
    source: values.source,
    service: values.service,
    need: values.need.trim(),
    serviceDate: "",
    location: "",
    estimate: Number(values.estimate) || 0,
    proposal: Number(values.proposal) || 0,
    status: values.status,
    owner: values.owner.trim(),
    lastContact: dateISO(),
    nextAction: values.nextAction.trim(),
    nextActionDate: values.nextActionDate,
    result: "Em aberto",
    lossReason: "",
    closeDate: "",
    afterSales: "Não aplicável",
    rating: "",
    nextContact: values.nextActionDate,
    notes: ""
  };
  opportunities.unshift(record);
  persistRecords();
  render();
  document.querySelector("#new-modal").close();
  form.reset();
  showView("opportunities");
  showToast("Oportunidade criada e guardada neste navegador.");
});

const todayText = new Intl.DateTimeFormat("pt-PT", { weekday: "long", day: "numeric", month: "long" }).format(today);
document.querySelector("#today-label").textContent = todayText.toLocaleUpperCase("pt-PT");
populateSelect(document.querySelector("#status-filter"), STATUS_OPTIONS, "Todos os estados");
populateSelect(document.querySelector("#service-filter"), SERVICE_OPTIONS, "Todos os serviços");
fillNewFormOptions();
document.querySelector("#new-opportunity-form").elements.nextActionDate.value = dateISO(1);
render();
